# BDCLONE

git clone https://github.com/C4LLM3D3V1L/BDCLONE

cd BDCLONE

python BD-CLONE.py
